// llip_clientView.h : interface of the CLlip_clientView class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()

//}}AFX_INCLUDES

#if !defined(AFX_LLIP_CLIENTVIEW_H__CA882B9F_93AD_473A_B7EC_588C70793414__INCLUDED_)
#define AFX_LLIP_CLIENTVIEW_H__CA882B9F_93AD_473A_B7EC_588C70793414__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLlip_clientView : public CFormView
{
protected: // create from serialization only
	CLlip_clientView();
	DECLARE_DYNCREATE(CLlip_clientView)

public:
	//{{AFX_DATA(CLlip_clientView)
	enum { IDD = IDD_LLIP_CLIENT_FORM };
	CButton	m_button;
	CEdit	m_edit;
	CListCtrl	m_ListView;
	//}}AFX_DATA

// Attributes
public:
	CLlip_clientDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLlip_clientView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLlip_clientView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLlip_clientView)
	afx_msg void OnButton1();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit1();
};

#ifndef _DEBUG  // debug version in llip_clientView.cpp
inline CLlip_clientDoc* CLlip_clientView::GetDocument()
   { return (CLlip_clientDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LLIP_CLIENTVIEW_H__CA882B9F_93AD_473A_B7EC_588C70793414__INCLUDED_)
