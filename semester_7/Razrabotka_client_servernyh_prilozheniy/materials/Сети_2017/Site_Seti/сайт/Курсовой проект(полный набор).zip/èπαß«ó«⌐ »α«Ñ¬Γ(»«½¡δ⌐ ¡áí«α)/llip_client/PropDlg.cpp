// PropDlg.cpp : implementation file
//

#include "stdafx.h"
#include "llip_client.h"
#include "PropDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// PropDlg dialog


PropDlg::PropDlg(CWnd* pParent /*=NULL*/)
	: CDialog(PropDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(PropDlg)
	m_port = 250188;
	m_pwd = _T("");
	//}}AFX_DATA_INIT
}


void PropDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PropDlg)
	DDX_Control(pDX, IDC_IPADDRESS, m_ipAddr);
	DDX_Text(pDX, IDC_PORT, m_port);
	DDX_Text(pDX, IDC_PWD, m_pwd);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PropDlg, CDialog)
	//{{AFX_MSG_MAP(PropDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL PropDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ipAddr.SetAddress(127, 0, 0, 1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL PropDlg::DestroyWindow() 
{
	UpdateData();
	m_ipAddr.GetAddress(m_addr[0], m_addr[1], m_addr[2], m_addr[3]);
	
	return CDialog::DestroyWindow();
}
