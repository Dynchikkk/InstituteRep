// llip_clientDoc.h : interface of the CLlip_clientDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LLIP_CLIENTDOC_H__762917AF_A2CE_4624_9E55_113E846A57AE__INCLUDED_)
#define AFX_LLIP_CLIENTDOC_H__762917AF_A2CE_4624_9E55_113E846A57AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLlip_clientDoc : public CDocument
{
protected: // create from serialization only
	CLlip_clientDoc();
	DECLARE_DYNCREATE(CLlip_clientDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLlip_clientDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLlip_clientDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLlip_clientDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LLIP_CLIENTDOC_H__762917AF_A2CE_4624_9E55_113E846A57AE__INCLUDED_)
