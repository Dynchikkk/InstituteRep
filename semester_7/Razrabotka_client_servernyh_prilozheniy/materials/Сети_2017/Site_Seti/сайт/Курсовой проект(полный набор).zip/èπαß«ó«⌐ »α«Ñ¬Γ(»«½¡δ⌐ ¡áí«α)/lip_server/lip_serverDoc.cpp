// lip_serverDoc.cpp : implementation of the CLip_serverDoc class
//

#include "stdafx.h"
#include "lip_server.h"

#include "lip_serverDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLip_serverDoc

IMPLEMENT_DYNCREATE(CLip_serverDoc, CDocument)

BEGIN_MESSAGE_MAP(CLip_serverDoc, CDocument)
	//{{AFX_MSG_MAP(CLip_serverDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLip_serverDoc construction/destruction

CLip_serverDoc::CLip_serverDoc()
{
	// TODO: add one-time construction code here

}

CLip_serverDoc::~CLip_serverDoc()
{
}

BOOL CLip_serverDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CLip_serverDoc serialization

void CLip_serverDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLip_serverDoc diagnostics

#ifdef _DEBUG
void CLip_serverDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CLip_serverDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLip_serverDoc commands
