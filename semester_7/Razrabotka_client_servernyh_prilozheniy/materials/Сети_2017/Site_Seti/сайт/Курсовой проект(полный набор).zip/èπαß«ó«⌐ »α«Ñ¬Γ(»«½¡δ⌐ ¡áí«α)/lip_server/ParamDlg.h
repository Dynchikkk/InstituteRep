#if !defined(AFX_PARAMDLG_H__C94C52F6_85AE_4E6D_AEC8_47E4D4CCAD3A__INCLUDED_)
#define AFX_PARAMDLG_H__C94C52F6_85AE_4E6D_AEC8_47E4D4CCAD3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ParamDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ParamDlg dialog

class ParamDlg : public CDialog
{
// Construction
public:
	ParamDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ParamDlg)
	enum { IDD = IDD_PARAM };
	int		m_Port;
	CString	m_Password;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ParamDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ParamDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARAMDLG_H__C94C52F6_85AE_4E6D_AEC8_47E4D4CCAD3A__INCLUDED_)
