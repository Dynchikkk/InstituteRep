// lip_server.h : main header file for the LIP_SERVER application
//

#if !defined(AFX_LIP_SERVER_H__CCE96B90_1EF6_4756_BEFC_365B9AE01FD3__INCLUDED_)
#define AFX_LIP_SERVER_H__CCE96B90_1EF6_4756_BEFC_365B9AE01FD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CLip_serverApp:
// See lip_server.cpp for the implementation of this class
//

class CLip_serverApp : public CWinApp
{
public:
	CLip_serverApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLip_serverApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CLip_serverApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LIP_SERVER_H__CCE96B90_1EF6_4756_BEFC_365B9AE01FD3__INCLUDED_)
