// llip_clientView.cpp : implementation of the CLlip_clientView class
//

#include "stdafx.h"
#include "llip_client.h"

#include "llip_clientDoc.h"
#include "llip_clientView.h"
#include "..\crypt.h"
#include ".\llip_clientview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLlip_clientView

IMPLEMENT_DYNCREATE(CLlip_clientView, CFormView)

BEGIN_MESSAGE_MAP(CLlip_clientView, CFormView)
	//{{AFX_MSG_MAP(CLlip_clientView)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(IDC_EDIT1, OnEnChangeEdit1)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLlip_clientView construction/destruction

CLlip_clientView::CLlip_clientView()
	: CFormView(CLlip_clientView::IDD)
{
	//{{AFX_DATA_INIT(CLlip_clientView)
	//}}AFX_DATA_INIT
	// TODO: add construction code here
}

CLlip_clientView::~CLlip_clientView()
{
}

void CLlip_clientView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLlip_clientView)
	DDX_Control(pDX, IDC_BUTTON1, m_button);
	DDX_Control(pDX, IDC_EDIT1, m_edit);
	DDX_Control(pDX, IDC_LIST1, m_ListView);
	//}}AFX_DATA_MAP
}

BOOL CLlip_clientView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CLlip_clientView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CLlip_clientView diagnostics

#ifdef _DEBUG
void CLlip_clientView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLlip_clientView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLlip_clientDoc* CLlip_clientView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLlip_clientDoc)));
	return (CLlip_clientDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLlip_clientView message handlers

void CLlip_clientView::OnButton1() 
{
	SOCKET s = ((CLlip_clientApp*) AfxGetApp())->s;
	char *pwd = ((CLlip_clientApp*) AfxGetApp())->m_pwd;

	char str[500],		 // ����� ��� ������
		 encrypted[500]; // ����� ��� ������������ ������
	int nFields, i;
	
	int len = m_edit.GetWindowText(str, sizeof (str) - 1);
	str[len] = '\0';
	len = crypt(str, encrypted, pwd, ++len);

	send(s, (char*)&len, sizeof len, 0);
	if (send(s, encrypted, len, 0) == SOCKET_ERROR) {
		MessageBox("������ ��������� ������.", "������");
		m_button.EnableWindow(false);
		return;
	}
	recv(s, (char*)&nFields, sizeof nFields, 0);

	if (nFields == 0) {
		MessageBox("������ �������� ������", "������");
		return;
	}

	m_ListView.DeleteAllItems();
	while(m_ListView.DeleteColumn(0));
	
	for(i = 0; i < nFields; i++) {
		recv(s, (char*)&len, sizeof len, 0);
		recv(s, encrypted, (int) len, 0);
		crypt(encrypted, str, pwd, len);
		m_ListView.InsertColumn(i, str, LVCFMT_LEFT, 80);
	}
	do {
		for(i = 0; i < nFields; i++) {
			recv(s, (char*)&len, sizeof len, 0);
			recv(s, encrypted, (int) len, 0);
			crypt(encrypted, str, pwd, len);
			if (i == 0)
				m_ListView.InsertItem(0, str);
			else
				m_ListView.SetItemText(0, i, str);
		}
		recv(s, (char*)&len, 1, 0);
	} while(len == 1);

}

void CLlip_clientView::OnEditCopy() 
{
	m_edit.Copy();		
}

void CLlip_clientView::OnEditCut() 
{
	m_edit.Cut();		
}

void CLlip_clientView::OnEditPaste() 
{
	m_edit.Paste();		
}

void CLlip_clientView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);

	if (m_ListView.m_hWnd) {
		m_ListView.MoveWindow(10, 190, cy + 50 ,cx - 380 );
		m_edit.MoveWindow(10, 25,cx - 100,  cy - 210);
		m_button.MoveWindow(cx - 200, 145, 100, 25);
	}
}

void CLlip_clientView::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
