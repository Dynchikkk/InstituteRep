// lip_serverView.cpp : implementation of the CLip_serverView class
//

#include "stdafx.h"
#include "lip_server.h"

#include "lip_serverDoc.h"
#include "lip_serverView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLip_serverView

IMPLEMENT_DYNCREATE(CLip_serverView, CFormView)

BEGIN_MESSAGE_MAP(CLip_serverView, CFormView)
	//{{AFX_MSG_MAP(CLip_serverView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLip_serverView construction/destruction

CLip_serverView::CLip_serverView()
	: CFormView(CLip_serverView::IDD)
{
	//{{AFX_DATA_INIT(CLip_serverView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CLip_serverView::~CLip_serverView()
{
}

void CLip_serverView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLip_serverView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CLip_serverView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CLip_serverView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CLip_serverView diagnostics

#ifdef _DEBUG
void CLip_serverView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLip_serverView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLip_serverDoc* CLip_serverView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLip_serverDoc)));
	return (CLip_serverDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLip_serverView message handlers
