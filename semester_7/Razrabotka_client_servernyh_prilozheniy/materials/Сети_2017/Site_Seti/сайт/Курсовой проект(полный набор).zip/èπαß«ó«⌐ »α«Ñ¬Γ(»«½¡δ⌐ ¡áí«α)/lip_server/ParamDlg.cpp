// ParamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "lip_server.h"
#include "ParamDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ParamDlg dialog


ParamDlg::ParamDlg(CWnd* pParent)
	: CDialog(ParamDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ParamDlg)
	m_Port = 250188;
	m_Password = _T("");
	//}}AFX_DATA_INIT
}


void ParamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ParamDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Port);
	DDX_Text(pDX, IDC_EDIT2, m_Password);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ParamDlg, CDialog)
	//{{AFX_MSG_MAP(ParamDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
