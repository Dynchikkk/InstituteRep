
unsigned long gamma(char *pwd);

int crypt(const char *source, char *dest, char *pwd, int len);