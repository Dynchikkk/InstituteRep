// lip_serverView.h : interface of the CLip_serverView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LIP_SERVERVIEW_H__11462A9C_C604_4D36_9950_126DBA6556A7__INCLUDED_)
#define AFX_LIP_SERVERVIEW_H__11462A9C_C604_4D36_9950_126DBA6556A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLip_serverView : public CFormView
{
protected: // create from serialization only
	CLip_serverView();
	DECLARE_DYNCREATE(CLip_serverView)

public:
	//{{AFX_DATA(CLip_serverView)
	enum{ IDD = IDD_LIP_SERVER_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CLip_serverDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLip_serverView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLip_serverView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLip_serverView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in lip_serverView.cpp
inline CLip_serverDoc* CLip_serverView::GetDocument()
   { return (CLip_serverDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LIP_SERVERVIEW_H__11462A9C_C604_4D36_9950_126DBA6556A7__INCLUDED_)
