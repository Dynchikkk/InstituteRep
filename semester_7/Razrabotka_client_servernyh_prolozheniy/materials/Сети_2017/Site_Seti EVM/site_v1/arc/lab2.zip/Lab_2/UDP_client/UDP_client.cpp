// UDPclientconsol.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <WinSock2.h>

#pragma once
#pragma comment (lib,"wsock32.lib")
#pragma comment (lib, "ws2_32.lib")

SOCKET sock_out;

#define PASSWORD	"password"
#define PORT_SERVER 3030
#define PORT_CLIENT 3050
#define IP_SERVER	"127.0.0.2"
#define IP_CLIENT	"127.0.0.1"

BOOL CreateOutgoingSocket(void);

int _tmain(int argc, _TCHAR* argv[])
{	
	WSADATA                 wsd;			// ��������� ��� WSAStartup
	WSAStartup(MAKEWORD(2, 2), &wsd);		// ���������������� ���������� WinSock
	BOOL	COS;
	int		BufLen;
	char	SendBuf[100];
	char	crypt_message[100];			// �������������� ������������� �����
	struct sockaddr_in s_address;

	COS=CreateOutgoingSocket();
	if (COS==TRUE)
		printf("Client is running...\n");
	else
		printf("Can't create socket!\n");
	if(sock_out != INVALID_SOCKET) {
		memset(&s_address,0,sizeof(SOCKADDR_IN));
		s_address.sin_family = AF_INET;
		s_address.sin_addr.s_addr = inet_addr(IP_SERVER);
		s_address.sin_port = htons((WORD)PORT_SERVER);
	}

	while (1)
	{
		printf("Message: ");
		gets_s(SendBuf,99);
		BufLen=strlen(SendBuf);
		
		crypt(SendBuf,crypt_message,PASSWORD); // �����������

		sendto(sock_out,crypt_message,BufLen,0,(SOCKADDR *)&(s_address),sizeof(s_address)); 
		printf("Message was sent!\n");
		if (strcmp(SendBuf,"exit")==0)
			break;		
	}
	return 0;
}

BOOL CreateOutgoingSocket(void) //�������� ������, �������� UDP
{
	struct sockaddr_in srv_address;
	int namelen;

	sock_out=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (sock_out!=INVALID_SOCKET)
	{
		memset(&srv_address,0,sizeof(SOCKADDR_IN));
		srv_address.sin_addr.S_un.S_addr= inet_addr(IP_CLIENT);
		srv_address.sin_family = AF_INET;
		srv_address.sin_port = htons((WORD)PORT_CLIENT); 
	}


	if(bind(sock_out, (SOCKADDR *) &srv_address, sizeof(SOCKADDR_IN)) == SOCKET_ERROR) 
	{
		closesocket(sock_out);
		return FALSE;
	} 
	else 
	{
		namelen=sizeof(SOCKADDR_IN);
		getsockname(sock_out,(SOCKADDR *)&srv_address,&namelen);
		return TRUE;
	}

}