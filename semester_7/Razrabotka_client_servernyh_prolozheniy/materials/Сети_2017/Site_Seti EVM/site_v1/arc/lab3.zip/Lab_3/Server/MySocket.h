#pragma once

// CMySocket command target
class CServerDlg;
class CMySocket : public CSocket
{
public:
	CServerDlg* m_pDlg;
	CMySocket();
	virtual ~CMySocket();
	void SetParentDlg(CServerDlg *);
	virtual void OnAccept(int);
	virtual void OnReceive(int);
};


