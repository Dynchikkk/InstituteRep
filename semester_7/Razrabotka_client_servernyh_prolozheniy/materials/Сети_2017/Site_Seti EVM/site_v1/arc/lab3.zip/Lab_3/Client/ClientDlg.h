// ClientDlg.h : header file
//

#pragma once
#include "afxcmn.h"


int crypt(CString&, CString&, CString&);
// CClientDlg dialog
class CClientDlg : public CDialog
{
// Construction
public:
	CClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_CLIENT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_mess;
	CString m_pass;
public:
	CIPAddressCtrl m_ip;
public:
	afx_msg void OnBnClickedCheck1();
public:
	BOOL m_bpass;
public:
	BOOL m_ctcp;
public:
	afx_msg void OnBnClickedButton1();
public:
	afx_msg void OnBnClickedButton2();
	
public:
	CString m_log;
public:
	afx_msg void OnBnClickedButton3();
};
