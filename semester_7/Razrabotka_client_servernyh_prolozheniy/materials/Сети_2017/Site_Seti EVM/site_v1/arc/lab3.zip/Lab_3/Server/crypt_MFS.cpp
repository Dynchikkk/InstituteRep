#include "stdafx.h"

unsigned short gamma(CString pwd)
{
	CString buf;
	int i;
	unsigned short g,flag;

	memset(buf.GetBufferSetLength(20),0x55,20);
	memcpy(buf.GetBufferSetLength(20),pwd,pwd.GetLength());
	for (i=0, g=0; i<20; i++)
		g+=(unsigned short) buf[i];
	for (i=5; i>0; i--)
	{
		flag=g&1;
		g=g>>1;
		if (flag) g |= 0x8000;
	}

	return g;
}

int crypt(CString &source, CString &dest, CString &pwd)
{
	int i, len;
	unsigned short *px, *py, g;

	px = (unsigned short *)source.GetBufferSetLength(32); 
	py = (unsigned short *)dest.GetBufferSetLength(32); 
	g = gamma(pwd); 
	len = source.GetLength(); 
	for(i=0; i < len+1; i++, py++, px++)
		*py = *px ^ g;   
	return len+1;
}
