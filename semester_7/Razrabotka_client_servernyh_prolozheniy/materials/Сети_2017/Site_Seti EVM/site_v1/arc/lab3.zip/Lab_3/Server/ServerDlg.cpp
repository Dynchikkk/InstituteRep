// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About
//HANDLE hThread;
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CServerDlg dialog




CServerDlg::CServerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerDlg::IDD, pParent)
	, m_pass(_T(""))
	, m_bpass(FALSE)
	, m_ctcp(FALSE)
	, m_log(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_pass);
	DDV_MaxChars(pDX, m_pass, 20);
	DDX_Check(pDX, IDC_CHECK1, m_bpass);
	DDX_Text(pDX, IDC_EDIT2, m_log);
	DDX_Radio(pDX, IDC_RADIO1, m_ctcp);
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_START, &CServerDlg::OnBnClickedStart)
	ON_BN_CLICKED(IDC_CHECK1, &CServerDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_STOP, &CServerDlg::OnBnClickedStop)
END_MESSAGE_MAP()


// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_pListenSocket.SetParentDlg(this);
	m_pConnectSocket.SetParentDlg(this);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
#define IP_SERVER L"127.0.0.2"
#define PORT_SERVER 3030
CSocket udp;
BOOL fl=0;

UINT ThreadProc(LPVOID param)  //�������� ��������� �������
//DWORD WINAPI ThreadProc(LPVOID param)
{
	TCHAR buf[100];
	TCHAR log[100];
	CString adr;
	UINT clport=3050;
	CString pBuf,mess,pass,m_log;
	
	
	udp.Create(PORT_SERVER,SOCK_DGRAM,IP_SERVER);
	udp.m_nTimeOut=100;

while (fl==1)
{
	GetDlgItemText((HWND)param,IDC_EDIT1,buf,20);
	pass.Format(L"%s",buf);
	adr=L"127.0.0.1";
	udp.ReceiveFrom(buf,99,adr,clport);
	pBuf.Format(L"%s",buf);
	if (IsDlgButtonChecked((HWND)param,IDC_CHECK1)==BST_CHECKED)
		crypt(pBuf,mess,pass);
	else mess=pBuf;

	GetDlgItemText((HWND)param,IDC_EDIT2,log,1024);
	m_log.Format(L"%s",log);
	m_log+=L"\r\n���������: "+mess;
	if (fl==1) SetDlgItemText((HWND)param,IDC_EDIT2,m_log);
}
	udp.Close();

	return 0;
}

void CServerDlg::OnBnClickedStart()
{
	//TCHAR buf[100];
	CString adr;
	UINT clport=3050;
	CString pBuf,mess;
fl=1;
	UpdateData(TRUE);
	GetDlgItem (IDC_START)->EnableWindow(FALSE);
	GetDlgItem (IDC_CHECK1)->EnableWindow(FALSE);
	GetDlgItem (IDC_EDIT1)->EnableWindow(FALSE);
	GetDlgItem (IDC_RADIO1)->EnableWindow(FALSE);
	GetDlgItem (IDC_RADIO2)->EnableWindow(FALSE);

	
	if (!m_ctcp) 
	{
		m_pListenSocket.Create(PORT_SERVER,m_ctcp==FALSE?SOCK_STREAM:SOCK_DGRAM,m_ctcp==TRUE?IP_SERVER:NULL);
		m_pListenSocket.Listen(5);

	}
	else
		AfxBeginThread(ThreadProc,GetSafeHwnd()); 

	GetDlgItem (IDC_STOP)->EnableWindow(TRUE);
}


void CServerDlg::OnCancel()
{
	if (fl==1)
	{
		OnBnClickedStop();
	int res=MessageBox(L"������ UDP ����������! ����� �� ���������?",L"��������������!",MB_YESNO | MB_ICONQUESTION);
	if (res==6)
		OnOK();
	}
	else OnOK();

}
void CServerDlg::OnBnClickedCheck1()
{
	UpdateData(true);
	CEdit *epas = (CEdit *)(this->GetDlgItem(IDC_EDIT1));
	epas->SetReadOnly(!m_bpass);
	// TODO: Add your control notification handler code here
}

void CServerDlg::OnBnClickedStop()
{
	
	GetDlgItem (IDC_STOP)->EnableWindow(FALSE);

	fl=0;
	Sleep(0);
	udp.CancelBlockingCall();
	if (!m_ctcp)	m_pListenSocket.Close();
	m_log.Empty();

	GetDlgItem (IDC_CHECK1)->EnableWindow(TRUE);
	GetDlgItem (IDC_EDIT1)->EnableWindow(TRUE);
	GetDlgItem (IDC_RADIO1)->EnableWindow(TRUE);
	GetDlgItem (IDC_RADIO2)->EnableWindow(TRUE);
	GetDlgItem (IDC_START)->EnableWindow(TRUE);
	UpdateData(FALSE);
}
void CServerDlg::OnAccept()
{
	//��������� ���������� �� ���������� �����
	m_pListenSocket.Accept(m_pConnectSocket);
	CString adr;
	UINT port;
	m_pConnectSocket.GetPeerName(adr,port);
	UpdateData(TRUE);
	m_log+=L"\r\n���������� ����������� � "+adr+L"\r\n";
	UpdateData(FALSE);
}

void CServerDlg::OnReceive()
{
 	UpdateData(TRUE);
	CString pBuf,mess;
	TCHAR szServerA[100];
	int n=m_pConnectSocket.Receive(szServerA, 99);
 	pBuf.Format(L"%s",szServerA);
 	if (m_bpass)crypt(pBuf,mess,m_pass);
 	else mess=pBuf;
 	m_log+=L"���������: "+mess;
 	UpdateData(FALSE);
 	m_pConnectSocket.Close();
}

