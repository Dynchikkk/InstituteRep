// ClientDlg.cpp : implementation file
//


#include "stdafx.h"
#include "Client.h"
#include "ClientDlg.h"

#ifdef _DEBUG 
#define new DEBUG_NEW
#endif
	CSocket ClientSocket;
#define IP_CLIENT L"127.0.0.1"
#define PORT_CLIENT 3050
#define PORT_SERVER 3030
	
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CClientDlg dialog




CClientDlg::CClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientDlg::IDD, pParent)
	, m_mess(_T(""))
	, m_pass(_T(""))
	, m_bpass(FALSE)
	, m_ctcp(FALSE)
	, m_log(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_mess);
	DDV_MaxChars(pDX, m_mess, 100);
	DDX_Control(pDX, IDC_IPADDRESS1, m_ip);
	DDX_Text(pDX, IDC_EDIT1, m_pass);
	DDV_MaxChars(pDX, m_pass, 10);	
	DDX_Check(pDX, IDC_CHECK1, m_bpass);
	DDX_Radio(pDX, IDC_TCP, m_ctcp);
	DDX_Text(pDX, IDC_EDIT3, m_log);
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK1, &CClientDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_BUTTON1, &CClientDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CClientDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CClientDlg::OnBnClickedButton3)
END_MESSAGE_MAP()


// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CClientDlg::OnBnClickedCheck1()
{
		UpdateData(true);
		CEdit *epas = (CEdit *)(this->GetDlgItem(IDC_EDIT1));
		 epas->SetReadOnly(!m_bpass);
}
 
void CClientDlg::OnBnClickedButton1()
{
	TCHAR adr[16];
	UpdateData(true);

		if (m_ip.IsBlank())
		{
			m_log=m_log+L"Uncorrect IP!\r\n";
			UpdateData(FALSE);
			return;
		}
		if (!ClientSocket.Create(m_ctcp==FALSE?NULL:3050,m_ctcp==FALSE?SOCK_STREAM:SOCK_DGRAM ,m_ctcp==TRUE?IP_CLIENT:NULL)) 
		{
			m_log=m_log+L"Creating socket failed!\r\n";
			UpdateData(FALSE);
			return;
		}

	GetDlgItem (IDC_BUTTON1)->EnableWindow(FALSE);
	m_ip.GetWindowText(adr,16); 

	if (m_ctcp==FALSE)
	{
		m_log=m_log+L"Connecting...\r\n";
		UpdateData(FALSE);

		if (!ClientSocket.Connect(adr, 3030))
		{
			m_log=m_log+L"Connecting failed!\r\n";
			ClientSocket.Close();
			GetDlgItem (IDC_BUTTON1)->EnableWindow(TRUE);
			UpdateData(FALSE);
			return;
		}
		else
		{	
			GetDlgItem (IDC_BUTTON2)->EnableWindow(TRUE);
			m_log=m_log+L"Connected!\r\n";
		}
	}
	else	GetDlgItem (IDC_BUTTON2)->EnableWindow(TRUE);

	UpdateData(FALSE);
	return;
}

void CClientDlg::OnBnClickedButton2()
{
	CString mess;
	TCHAR adr[16];
	TCHAR www[100];
	//char str[200];
	UpdateData(true);

	if (m_pass.IsEmpty() && m_bpass)
	{
		m_log=m_log+L"Enter password!\r\n";
		UpdateData(FALSE);
		return;
	}
	
	if (m_bpass)crypt(m_mess,mess,m_pass);
	else mess=m_mess;
	
	wcscpy_s(www,mess.GetBufferSetLength(mess.GetLength()));

	if (m_ctcp)
	{
		//UDP
		m_ip.GetWindowText(adr,16); 
	//	wcstombs(str, www, sizeof(www)); //��� ANSI �������
		if (ClientSocket.SendTo(www,99,PORT_SERVER,adr)==NULL)
			m_log=m_log+L"Sending failed!\r\n"; 
		else m_log=m_log+L"Message was sent!\r\n";
	}
	else
	{
		//TCP
		if (ClientSocket.Send(www,99, 0)==NULL)
			m_log=m_log+L"Sending failed!\r\n"; 
		else m_log=m_log+L"Message was sent!\r\nDisconnected!\r\n";
	}

	UpdateData(FALSE);
	ClientSocket.Close(); 
	GetDlgItem (IDC_BUTTON1)->EnableWindow(TRUE);
	GetDlgItem (IDC_BUTTON2)->EnableWindow(FALSE);
}

void CClientDlg::OnBnClickedButton3()
{
	m_ip.SetAddress(127,0,0,1);
}
