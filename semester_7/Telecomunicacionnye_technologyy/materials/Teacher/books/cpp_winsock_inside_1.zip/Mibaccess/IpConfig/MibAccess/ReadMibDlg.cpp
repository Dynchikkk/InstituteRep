// ReadMibDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ReadMib.h"
#include "ReadMibDlg.h"

#include "MibAccess.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReadMibDlg dialog

CReadMibDlg::CReadMibDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReadMibDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReadMibDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CReadMibDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReadMibDlg)
	DDX_Control(pDX, IDOK, m_OK);
	DDX_Text(pDX, IDC_EDIT, m_Edit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CReadMibDlg, CDialog)
	//{{AFX_MSG_MAP(CReadMibDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReadMibDlg message handlers

CString TypeIP(DWORD ip)
{
	CString s;
	s.Format("%d.%d.%d.%d", 
		(ip & 0xff) ,
		(ip & 0xff00) >> 8,
		(ip & 0xff0000) >> 16,
		(ip & 0xff000000)>>24);
	return s;
}
BOOL CReadMibDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	MibII m;
	UINT IPArray[50];
	UINT IPArraySize =50;
  m.Init();
	if(m.GetIPAddress(IPArray,IPArraySize)){
		UINT MaskArray[50];
		UINT MaskArraySize =50;
		if(m.GetIPMask(MaskArray,MaskArraySize))
		{
			m_Edit="";
			UINT i;
			for(i=0; i< MaskArraySize; i++){
				m_Edit += "ip: " + TypeIP(IPArray[i])+
					" mask: " + TypeIP(MaskArray[i])+ "\r\n";

			}
		}
    UpdateData(FALSE);
	}	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CReadMibDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CReadMibDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
