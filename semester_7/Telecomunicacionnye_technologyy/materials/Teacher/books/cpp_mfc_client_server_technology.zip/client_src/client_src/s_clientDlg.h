// s_clientDlg.h : header file
//

#if !defined(AFX_S_CLIENTDLG_H__7E477285_93F1_11D4_8163_CAFF6EB92413__INCLUDED_)
#define AFX_S_CLIENTDLG_H__7E477285_93F1_11D4_8163_CAFF6EB92413__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CS_clientDlg dialog

class MySocket;
class CS_clientDlg : public CDialog
{
// Construction
public:
	void AddText(LPCTSTR lpszString);
	CString CfgFile;

	CButton *m_cConnect;
	MySocket *pSocket;
	CString m_sMessage;
	CS_clientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CS_clientDlg)
	enum { IDD = IDD_S_CLIENT_DIALOG };
	CString	Name;
	CString	ip;
	//}}AFX_DATA


        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CSendDialog)
        protected:
        virtual void DoDataExchange(CDataExchange* pDX);    // D
        //}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CS_clientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConnect();
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_S_CLIENTDLG_H__7E477285_93F1_11D4_8163_CAFF6EB92413__INCLUDED_)
