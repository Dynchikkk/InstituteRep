// s_client.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "s_client.h"
#include "s_clientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CS_clientApp

BEGIN_MESSAGE_MAP(CS_clientApp, CWinApp)
	//{{AFX_MSG_MAP(CS_clientApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CS_clientApp construction

CS_clientApp::CS_clientApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CS_clientApp object

CS_clientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CS_clientApp initialization

BOOL CS_clientApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CS_clientDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
