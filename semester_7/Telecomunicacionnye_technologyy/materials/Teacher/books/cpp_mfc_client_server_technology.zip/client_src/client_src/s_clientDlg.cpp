// s_clientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "s_client.h"
#include "s_clientDlg.h"
#include "MySocket.h"
#include <strstrea.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About



/////////////////////////////////////////////////////////////////////////////
// CS_clientDlg dialog

CS_clientDlg::CS_clientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CS_clientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CS_clientDlg)
	Name = _T("");
	ip = _T("");
	//}}AFX_DATA_INIT
	if (AfxGetApp()->m_lpCmdLine[0] != '\0')
	{
        TCHAR strCfgFile[128];

        istrstream(AfxGetApp()->m_lpCmdLine) >> strCfgFile ;
		CfgFile=CString(strCfgFile);
		CStdioFile outFile;
		CFileException fileException;
		if ( !outFile.Open(CfgFile,CFile::modeRead ) )
		{
			TRACE( "Can't open file %s, error = %u\n", CfgFile, fileException.m_cause );
			outFile.Close();
			MessageBox("File error","");
			return;
		}
		outFile.ReadString(Name);
		outFile.ReadString(ip);
		outFile.Close();
	}
	else
	{
		Name="Noname1";
		ip="127.0.0.1";
	}
}

void CS_clientDlg::DoDataExchange(CDataExchange* pDX)
{
        CDialog::DoDataExchange(pDX);
        //{{AFX_DATA_MAP(CSendDialog)
        DDX_Text(pDX, IDC_EDIT1, Name);
        DDV_MaxChars(pDX, Name, 4000);
        DDX_Text(pDX, IDC_EDIT2, ip);
        DDV_MaxChars(pDX, ip, 4000);
        //}}AFX_DATA_MAP
}



BEGIN_MESSAGE_MAP(CS_clientDlg, CDialog)
	//{{AFX_MSG_MAP(CS_clientDlg)
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CS_clientDlg message handlers

BOOL CS_clientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cConnect=(CButton*)GetDlgItem(IDC_CONNECT);
	SetDlgItemText(IDC_ANSWER,"application loaded");
	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CS_clientDlg::OnConnect() 
{

    pSocket = new MySocket(this);

    pSocket->Create();
	GetDlgItemText(IDC_EDIT2,ip);
	if(pSocket->Connect(ip, 2049))
	{
		m_cConnect->EnableWindow(FALSE);
		GetDlgItemText(IDC_EDIT1,Name);
		pSocket->Send(Name,Name.GetLength());
	}
	else 
		delete pSocket;
	/*
	int err=pSocket->GetLastError();
	if(err==10035)
	{
		CString s ;
		s.Format("ret=%d  errcode=%d",r,err);
		AfxMessageBox(s);
	}
	*/
	
}

void CS_clientDlg::OnSend() 
{
	GetDlgItemText(IDC_MESSAGE,m_sMessage);
	if(pSocket!=NULL&&m_sMessage.GetLength()!=0)
	pSocket->Send(m_sMessage,80);
}


void CS_clientDlg::AddText(LPCTSTR lpszString)
{
	CEdit *pEdit=(CEdit*)GetDlgItem(IDC_ANSWER);
	int len=pEdit->GetWindowTextLength();
	pEdit->SetSel(len,len);
	pEdit->SendMessage(WM_CHAR,WPARAM(13),LPARAM(28));
	pEdit->ReplaceSel(lpszString);


}
