// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "server4.h"
#include "ChildView.h"
#include "ClientSocket.h"
#include "SendDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_LBN_DBLCLK(IDR_LISTBOX,OnListToggle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	
	// Do not call CWnd::OnPaint() for painting messages
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	listbox.Create(LBS_NOTIFY|LBS_NOINTEGRALHEIGHT|WS_CHILD|WS_VISIBLE,CRect(23,56,100,100),this,IDR_LISTBOX);
	editbox.CreateEx(CRect(0,0,0,0),this,1);
	pool.Init(this,PORT1);
	return 0;
}

void CChildView::OnSize(UINT nType, int cx, int cy) 
{
	CWnd ::OnSize(nType, cx, cy);
	listbox.MoveWindow(0,0,cx/2,cy,TRUE) ;
	editbox.MoveWindow(cx/2,0,cx/2,cy,TRUE) ;
}

void CChildView::OnListToggle()
{
        CSendDialog dlg;
        dlg.m_data="message to send";
        if( dlg.DoModal() == IDOK )
        {
                int i=listbox.GetCurSel();
                pool.Send(i,dlg.m_data);
        }
}

BOOL CChildView::UpdateView()
{
	CString ip,name;
	unsigned int port=PORT1;
	CClientSocket *pSock;

	listbox.ResetContent();
	POSITION pos = pool.connectionList.GetHeadPosition();
	for (int i=0;i < pool.connectionList.GetCount();i++)
	{
		pSock=(CClientSocket*)pool.connectionList.GetNext(pos);
		pSock->GetPeerName(ip,port);
		name=CString(pSock->Name+"  ip:"+ip);
		listbox.AddString(name);
	}
	return TRUE;
}


void CChildView::UpdateLog(LPCTSTR lpszString)
{
	editbox.AddText(lpszString);	
}

