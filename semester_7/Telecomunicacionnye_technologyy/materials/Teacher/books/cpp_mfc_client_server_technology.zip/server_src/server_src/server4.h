// server4.h : main header file for the SERVER4 application
//

#if !defined(AFX_SERVER4_H__16AB8E8C_FA95_11D4_8163_817FEAD65F16__INCLUDED_)
#define AFX_SERVER4_H__16AB8E8C_FA95_11D4_8163_817FEAD65F16__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CServer4App:
// See server4.cpp for the implementation of this class
//

#define PORT1 2049

class CServer4App : public CWinApp
{
public:
	CServer4App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServer4App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CServer4App)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVER4_H__16AB8E8C_FA95_11D4_8163_817FEAD65F16__INCLUDED_)
