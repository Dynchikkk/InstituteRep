// SendDialog.cpp : implementation file
//

#include "stdafx.h"
#include "server4.h"
#include "SendDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSendDialog dialog


CSendDialog::CSendDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSendDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSendDialog)
	m_data = _T("");
	//}}AFX_DATA_INIT
}


void CSendDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSendDialog)
	DDX_Text(pDX, IDC_EDIT1, m_data);
	DDV_MaxChars(pDX, m_data, 4000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSendDialog, CDialog)
	//{{AFX_MSG_MAP(CSendDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSendDialog message handlers
