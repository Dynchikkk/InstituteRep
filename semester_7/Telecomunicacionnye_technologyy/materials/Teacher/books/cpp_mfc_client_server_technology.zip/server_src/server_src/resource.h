//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by server4.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_LISTBOX                     101
#define CG_IDS_SOCKETS_INIT_FAILED      102
#define ID_INDICATOR2                   103
#define ID_INDICATOR1                   104
#define IDD_SEN_DIALOG                  105
#define IDR_MAINFRAME                   128
#define IDR_SERVERTYPE                  129
#define IDD_DTEST                       130
#define IDC_EDIT1                       1000
#define IDC_BUTTON2                     1002
#define IDC_BROADCAST                   1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
