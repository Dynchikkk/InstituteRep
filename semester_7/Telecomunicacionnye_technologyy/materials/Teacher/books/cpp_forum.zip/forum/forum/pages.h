

#include "config.h"
#include "string.h"


#ifndef PAGES_H   
#define PAGES_H

void ShowSuccessPage()
{
	cout<<"<HTML><HEAD><meta http-equiv=\"refresh\" content=\"10;URL="<<FORUM<<"?action=view&messages=all\">";
	cout<<"<TITLE>Message Sucessfully Posted..<TITLE>";
	cout<<"<link rel=\"stylesheet\" href=\""<<CSS<<"\"></HEAD><BODY bgcolor=\""<<BKGCOLOR<<"\">";
	cout<<"<table width=\"75%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" align=\"center\"><tr><td height=\"438\">";
	cout<<"Your Message has been Posted , click ";
	cout<<"<a href=\""<<FORUM<<"?action=view&messages=all\">";
	cout<<"here to go back, or u'll be redirected automatically after 10 sec.";
	cout<<"</td></tr></table></BODY></HTML>";
}
	
void ShowPostPage(STRING to)
{
	STRING title;
	if(strcmp(to,"none")) title="Reply to message";
		else title="post new message";
		
	cout<<"<html><head><title>"<<title<<"</title>";
	cout<<"<link rel=\"stylesheet\" href=\""<<CSS<<"\"></HEAD><BODY bgcolor=\""<<BKGCOLOR<<"\">";
	cout<<"<table width=\"75%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" align=\"center\"><tr><td height=\"438\">";
	cout<<"<p align=\"center\"><h1>"<<title<<"</h1></p>";
	cout<<"<form name=\"reply\" method=\"get\" action=\""<<FORUM<<"\">";
	cout<<" <p align=\"left\">name: <input type=\"text\" name=\"name\"  maxlength="<<MAXNAME <<"></p>";
	cout<<"<p align=\"left\"> email: <input type=\"text\" name=\"email\" maxlength="<<MAXEMAIL <<">";
	cout<<"<p align=\"left\"> pass: <input type=\"text\" name=\"passwd\" maxlength="<<MAXPASSWD <<">(leave blank if not registered)";
	cout<<"<input type=\"hidden\" name=\"rto\" value=\""<<to<<"\"  maxlength="<<MAXNUM <<"><br>";
	cout<<"<input type=\"hidden\" name=\"action\" value=\"post\"><br>";
	cout<<"message:<br><textarea name=\"msg\" cols=\"50\" rows=\"6\"  maxlength="<<MAXMSG <<"></textarea></p>";
	cout<<"<p align=\"center\"><input type=\"submit\" name=\"Submit\" value=\""<<title<<"\"></p>";
	cout<<"</form></td></tr></table></BODY></HTML>";
} 



void ShowRegSuccessPage()
{
	cout<<"<HTML><HEAD><meta http-equiv=\"refresh\" content=\"10;URL="<<FORUM<<"?action=view&messages=all\">";
	cout<<"<TITLE>User Successfully registered<TITLE>";
	cout<<"<link rel=\"stylesheet\" href=\""<<CSS<<"\"></HEAD><BODY bgcolor=\""<<BKGCOLOR<<"\">";
	cout<<"<table width=\"75%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" align=\"center\"><tr><td height=\"438\">";
	cout<<"Now u r Reegistered , click ";
	cout<<"<a href=\""<<FORUM<<"?action=view&messages=all\">";
	cout<<"here to go back, or u'll be redirected automatically after 10 sec.";
	cout<<"</td></tr></table></BODY></HTML>";	
}
	

void ShowRegPage()
{

        cout<<"<html><head><title>register..</title>";
	cout<<"<link rel=\"stylesheet\" href=\""<<CSS<<"\"></HEAD><BODY bgcolor=\""<<BKGCOLOR<<"\">";
	cout<<"<table width=\"75%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" align=\"center\"><tr><td height=\"438\">";
	cout<<"<p align=\"center\"><h1>registration..</h1></p>";
	cout<<"<form name=\"reg\" method=\"get\" action=\""<<FORUM<<"\">";
	cout<<" <p align=\"left\">name: <input type=\"text\" name=\"name\"  maxlength="<<MAXNAME <<"></p>";
	cout<<"<p align=\"left\"> email: <input type=\"text\" name=\"email\" maxlength="<<MAXEMAIL <<">";
	cout<<"<p align=\"left\"> pass: <input type=\"text\" name=\"passwd\" maxlength="<<MAXPASSWD <<">";
	cout<<"<p align=\"left\"> pass again: <input type=\"text\" name=\"passwd2\" maxlength="<<MAXPASSWD <<">";
	cout<<"<input type=\"hidden\" name=\"action\" value=\"reg\"><br>";
	cout<<"password length must be: min."<<MINPASSWD<<" ,max. "<<MAXPASSWD<<" characters</p>";
	cout<<"<input type=\"submit\" name=\"Submit\" value=\"Register\">";
	cout<<"</form></td></tr></table></BODY></HTML>";	
	
}
	


#endif

