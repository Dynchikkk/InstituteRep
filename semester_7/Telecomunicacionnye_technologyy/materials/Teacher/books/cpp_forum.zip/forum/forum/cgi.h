#ifndef CGI_H
#define CGI_H

#include<stdlib.h>
#include<string.h>

char hextochar(char* in);
char* parse(char* fname);


char hextochar(char* in)
{
   //converts a two-char string of hex values into a char.
   int val=0;
   char ch = in[0];
   switch (ch)
   {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         val = (16*(int(ch)-48));
         break;
      default:
         val = (16*(int(ch)-55));
         break;
   }   
   ch = in[1];
   switch (ch)
   {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         val += (int(ch)-48);
         break;
      default:
         val += (int(ch)-55);
         break;
   }   
   return char(val);
}

char* parse(char* fname)
{ 
	
char* qs=getenv("QUERY_STRING");
	
if (qs==NULL) return NULL;	
if (strlen(qs)==0) return NULL;	

int i;
char* name=new char[strlen(fname)+1];
char* result=new char[strlen(qs)];
char* str;

strcpy(name,fname);
name[strlen(fname)]='=';
name[strlen(fname)+1]='\0';  

if(!strcmp(qs,name)) return NULL;

str=(char*)strstr(qs,name);


for (i=(int)strlen(name);i<(int)strlen(str);i++) if (str[i]=='+') str[i]=' ';

char* temp=new char[3];
int j=0;


for (i=(int)strlen(name); (str[i]!='&') && (str[i]!='\0');i++)	
{
	if (str[i]=='%')
	{    
	     temp[0]=str[i+1];
             temp[1]=str[i+2];
             temp[2]='\0';
             i+=2;
             result[j]=hextochar(temp);
             j++;
        }
        else 
        {
        	result[j]=str[i];
        	j++;
        }
        
}
result[j]='\0';



return result;
}

#endif