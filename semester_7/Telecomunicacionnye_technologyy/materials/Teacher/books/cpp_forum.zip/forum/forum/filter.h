#include "string.cpp"
///// filter.h
#ifndef FILTER_H
#define FILTER_H

//////// filter will return filtered string


STRING filter(const STRING src)
{
STRING tmp(src);


	

for(int i=0;i<tmp.Len();i++)
 { 
	if(tmp[i]=='<') {tmp=tmp.left(i)+(STRING)"&lt;"+tmp.right(tmp.Len()-i-1);continue;}
	if(tmp[i]=='>') {tmp=tmp.left(i)+(STRING)"&gt;"+tmp.right(tmp.Len()-i-1);continue;}
 }
	
return tmp;
}
	
//////// Filter will filter(modify) given string

void Filter(STRING& src)
{

for(int i=0;i<src.Len();i++)
 { 
	if(src[i]=='<') {src=src.left(i)+(STRING)"&lt;"+src.right(src.Len()-i-1);continue;}
	if(src[i]=='>') {src=src.left(i)+(STRING)"&gt;"+src.right(src.Len()-i-1);continue;}
 }
	
}

  
#endif                     