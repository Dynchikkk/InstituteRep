
#include <iostream.h>
#include "config.h"


void View()
{

STRING messages;
messages=parse("messages");

FILE* file=fopen(MAIN,"a+");
FILE* html=fopen(TOP,"a+");
FILE* num=fopen(NUMBERS,"r");

char* str=new char[500];

while(fgets(str,500,html)) cout<<str;
                                     
cout<<"<p align=\"center\">";
fgets(str,MAXNUM,num);                                     
cout<<str<<" messages in ";
fgets(str,MAXNUM,num);                                     
cout<<str<<" threads</p>";

if (strcmp(messages,"all"))
 {
 	int n=atoi(messages);
 	int msgcount=0;
 	while(fgets(str,500,file))
 	{
            if(msgcount>=n) break;
            cout<<str;
            if(str[0]!='<') msgcount++;
            
        }
        
 }
  
  else  while(fgets(str,500,file)) cout<<str;
    
fclose(html);
html=fopen(BOTTOM,"a+");
while(fgets(str,500,html)) cout<<str;	



}
