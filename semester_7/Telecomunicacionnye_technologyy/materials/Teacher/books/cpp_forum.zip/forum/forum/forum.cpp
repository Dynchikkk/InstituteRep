

#include <iostream.h>
#include <memory.h>
#include <string.h>
#include "string.cpp"
#include "cgi.h"
#include "filter.h"
#include "message.h"
#include "pages.h"
#include "view.h"
#include "reg.h"

void main()
{
STRING action;

cout<<"Content-Type: text/html \n\n";


action=filter(parse("action"));

if (!strcmp(action,"post"))
  {
	
	Message msg;
	msg.Post();
	ShowSuccessPage();
	
  }
	
if (!strcmp(action,"reply"))
  {
  	ShowPostPage(filter(parse("to")));
  }
  
if (!strcmp(action,"newmsg"))
  {
  	ShowPostPage(filter(parse("to")));
  }  

if (!strcmp(action,"view"))
  {
  	View();
  }
  

if (!strcmp(action,"register"))
  {
  	ShowRegPage();
  }  

if (!strcmp(action,"reg"))
  {
  	Register();
  	ShowRegSuccessPage();
  }
  

cout<<"unknown action";    


}
  
 
  
  
                     