
#ifndef CONFIG_H   
#define CONFIG_H

///////////////// Paths

///// ������������ ServerRoot 

#define FORUM  "/cgi-bin/forum/forum.cgi"
#define CSS    "/forum.css"
//======================================'

///////////  ������������  forum.cgi
#define USERS      "../../forumdata/users"
#define PASSWORDS  "../../forumdata/passwds" 
#define MAIN       "../../forumdata/forum" 
#define NUMBERS    "../../forumdata/num" 
#define TOP       "../../forumdata/pagetop"
#define BOTTOM    "../../forumdata/pagebottom"
#define BANNED_IPS "../../forumdata/bips" 


 //////// maximum lengths 
#define MAXNAME    20     // name
#define MAXEMAIL   20     // m@il
#define MAXSUBJECT 40     // subj
#define MAXMSG     400    // msg
#define MAXNUM     5      // replyto
#define MAXPASSWD  10     //password  

 //////// minimum lengths 
#define MINNAME    0     // name
#define MINEMAIL   6     // m@il
#define MINSUBJECT 0     // subj
#define MINMSG     0     // msg
#define MINNUM     0     // replyto
#define MINPASSWD  1     //

///////// error messages ==========================================

#define  NAMELEN_ERRMSG 	"error ! name is too long"
#define  EMAILLEN_ERRMSG  	"error ! email is too long"
#define  SUBJECTLEN_ERRMSG 	"subject is too long"
#define  MSGLEN_ERRMSG 		"error ! msg is too long"
#define  NUMLEN_ERRMSG  	"what r u doing ?"
#define  PASSWDLEN_ERRMSG       "error! password is too long"

#define NAME_IS_SHORT 		"error ! name is too short"
#define MAIL_IS_SHORT 		"error ! invalid email address"
#define SUBJECT_IS_SHORT 	"error ! subject  is too short"
#define MSG_IS_SHORT 		"error ! message is too short"
#define NUMBER_IS_SHORT 	"error ! no such msg"
#define PASSWD_IS_SHORT         "error ! password is too short"

#define IP_BANNED "your ip address is banned"

///////////////

#define BKGCOLOR "708C78"  //���� ����

//����� ������ ����� reply ��������� �������� ��� ��-���� ������
// #define REPLYBTN "<img src=\"reply.gif\" align=absmiddle>"
#define REPLYBTN "reply"

#endif

