

#ifndef MESSAGE_H
#define MESSAGE_H

#include <string.h>
#include <io.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include "string.cpp"
#include "cgi.h"
#include "config.h"
#include "check.h"

enum flag{THREADS,TOTAL,BOTH};

class Message
{
public:
	Message();
	~Message(){};
	
	void Post();
	
	
private:
      STRING name;
      STRING email;
      //STRING subject;
      STRING msg;
      STRING rto;
      STRING passwd;
      
      int reply;
      
      void Validate();
      
      void NewMsg();
      void ReplyTo(STRING to);
      
      char* GetMsgNum();
      void Increase(flag);
      

};

////////////////////////////////////////////////////////////////////////////

void Message::Validate()
{
 
 CHECKMAXLEN(name,MAXNAME,NAMELEN_ERRMSG);
 //CHECKMAXLEN(subject,MAXSUBJECT,SUBJECTLEN_ERRMSG);
 CHECKMAXLEN(email,MAXEMAIL,EMAILLEN_ERRMSG);
 CHECKMAXLEN(msg,MAXMSG,MSGLEN_ERRMSG);
 CHECKMAXLEN(rto,MAXNUM, NUMLEN_ERRMSG );
 CHECKMAXLEN(passwd,MAXPASSWD, PASSWDLEN_ERRMSG );
 
  CHECKMINLEN(name,MINNAME,NAME_IS_SHORT);
 //CHECKMINLEN(subject,MAXSUBJECT,SUBJECT_IS_SHORT	);
 CHECKMINLEN(email,MINEMAIL,MAIL_IS_SHORT);
 CHECKMINLEN(msg,MINMSG,MSG_IS_SHORT );
 CHECKMINLEN(rto,MINNUM,NUMBER_IS_SHORT );

 
////////// check 4 banned ips
 
CheckIP();
  	

check(name,passwd);	 


////////////////////////// 
}


///////////////////////////////

Message::Message()
{


name=filter(parse("name"));
email=filter(parse("email"));
//subject=filter(parse("subject"));
msg=filter(parse("msg"));
rto=filter(parse("rto"));
passwd=filter(parse("passwd"));

Validate();

if(!strcmp(rto,"none")) reply=0;
 else reply=1;  //atoi((char*)rto);

}

///////////////////////////////

void Message::Post()
{

if (reply) ReplyTo(rto);
 else NewMsg();

}
	 
///////////////////////////////

void Message::ReplyTo(STRING to)
{

time_t ct;
time(&ct);
char* curtime=new char[strlen(ctime(&ct))];
strcpy(curtime,ctime(&ct));
curtime[strlen(curtime)-1]='\0';

while(!access("__tmp__",00));

FILE * tmp=fopen("__tmp__","a+");
FILE * forum=fopen(MAIN,"r");
char* str=new char[500] ;                  
STRING temp=(STRING)"<!--"+to+(STRING)"-->\n";

while (fgets(str,500,forum))
{       
	
	if(strcmp(temp,str))  fputs(str,tmp); 
	
	 else
	  {
	  	fputs(str,tmp);
	  	fputs("<blockquote>posted by <a href=\"mailto:",tmp);
	  	fputs(email,tmp);
	  	fputs("\">",tmp);
	  	fputs(name,tmp);
	  	fputs("</a>&nbsp;on ",tmp);
	  	fputs(curtime,tmp);
	  	fputs("&nbsp;<a href=\"",tmp);
	  	fputs(FORUM,tmp);
	  	fputs("?action=reply&to=",tmp);
	  	fputs(GetMsgNum(),tmp);
	  	fputs("&\">",tmp);
	  	fputs(REPLYBTN,tmp);
	  	fputs("</a><br>",tmp);
	  	fputs(msg,tmp);
	  	fputs("\n<!--",tmp);
	  	fputs(GetMsgNum(),tmp);
	  	fputs("-->\n",tmp);
	  	fputs("</blockquote>\n",tmp);
	  	
	 } 	 	
}
	



                                         
fclose(forum);                 
fclose(tmp);                   
                               
remove(MAIN);                  
rename("__tmp__",MAIN);        
                               
Increase(TOTAL);		

}


///////////////////////////////


void Message::NewMsg()
{

time_t ct;
time(&ct);
char* curtime=new char[strlen(ctime(&ct))];
strcpy(curtime,ctime(&ct));
curtime[strlen(curtime)-1]='\0';

while(!access("__tmp__",00));

FILE * tmp=fopen("__tmp__","a+");
FILE * forum=fopen(MAIN,"r");
char* str=new char[500] ;                  

fputs("posted by <a href=\"mailto:",tmp);
fputs(email,tmp);
fputs("\">",tmp);
fputs(name,tmp);
fputs("</a>&nbsp; on ",tmp);
fputs(curtime,tmp);
fputs("&nbsp;<a href=\"",tmp);
fputs(FORUM,tmp);
fputs("?action=reply&to=",tmp);
fputs(GetMsgNum(),tmp);
fputs("&\">",tmp);
fputs(REPLYBTN,tmp);
fputs("</a><br>",tmp);
fputs(msg,tmp);
fputs("\n<!--",tmp);
fputs(GetMsgNum(),tmp);
fputs("-->\n",tmp);
fputs("<hr>\n",tmp);



while (fgets(str,500,forum)) fputs(str,tmp); 
                                         
fclose(forum);                 
fclose(tmp);                   
                               
remove(MAIN);                  
rename("__tmp__",MAIN);        
                               
Increase(BOTH);	

}

///////////////////////////////

char* Message::GetMsgNum()

{
FILE* numbers=fopen(NUMBERS,"r");
char* str=new char[MAXNUM];
fgets(str,MAXNUM,numbers);
fclose(numbers);
str[strlen(str)-1]='\0';

return str;
}


///////////////////////////////


void Message::Increase(flag msgs)
{

FILE* numbers=fopen(NUMBERS,"r");
char threads[MAXNUM],total[MAXNUM];
int n;
fgets(total,MAXNUM,numbers);
fgets(threads,MAXNUM,numbers);
fclose(numbers);

numbers=fopen(NUMBERS,"w");

if(msgs==TOTAL)
  {  
	n=atoi(total);
	itoa(++n,total,10);
	fputs(total,numbers);
	fputs("\n",numbers);
	fputs(threads,numbers);
	fputs("\n",numbers);
  }
  
if(msgs==BOTH)
  {  
	n=atoi(total);
	itoa(++n,total,10);
	fputs(total,numbers);
	fputs("\n",numbers);
	n=atoi(threads);
	itoa(++n,threads,10);
	fputs(threads,numbers);
	fputs("\n",numbers);
  }
     
fclose(numbers);

}



#endif