// SockListenerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SockListener.h"
#include "SockListenerDlg.h"
#include "ClientSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HGLOBAL gMem;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockListenerDlg dialog

CSockListenerDlg::CSockListenerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSockListenerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSockListenerDlg)	
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSockListenerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSockListenerDlg)	
	DDX_Control(pDX, IDC_LIST1, m_list1);	
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSockListenerDlg, CDialog)
	//{{AFX_MSG_MAP(CSockListenerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SHOWWINDOW()
	ON_WM_CREATE()	
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockListenerDlg message handlers

BOOL CSockListenerDlg::OnInitDialog()
{
	
	CDialog::OnInitDialog();		
	
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	if(!GetMyIP()){
		AfxMessageBox("Unable to get IP", MB_OK|MB_ICONERROR);	
	}
	else{
		m_MySocket.m_ptrDlg = this;
		m_MySocket.Create(PORT,SOCK_STREAM); 
		m_MySocket.Listen();
	}		
	return TRUE;  
}

void CSockListenerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSockListenerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSockListenerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/*
----------------------------------------------------------------------------------------------------------------
 Function name   : CSockListenerDlg::GetMyIP
 Description     : 
 Return type     : BOOL 
----------------------------------------------------------------------------------------------------------------
*/
BOOL CSockListenerDlg::GetMyIP()
{		
	HOSTENT *hs;
	UCHAR ch[4]={0};
	CString csInfo;

	::gethostname((LPSTR)(LPCTSTR)m_cshostname, 50);
	
	hs = gethostbyname((LPSTR)(LPCTSTR)m_cshostname);

	memcpy(ch, hs->h_addr,4);
	csInfo.Format("%s  %d.%d.%d.%d", m_cshostname, 
		ch[0], ch[1], ch[2], ch[3]);
	GetDlgItem(IDC_TEXT)->SetWindowText(csInfo);
	/*
	::WSAAsyncGetHostByName 
	(
		this->m_hWnd, WM_USER_HOSTNAME,
		(LPCTSTR) m_cshostname, m_szBufHostent, 
		MAXGETHOSTSTRUCT 
	);
	*/
	
return(TRUE);
}

void CSockListenerDlg::ProcessPendingAccept()
{
	CString csSockAddr;
	CString csInfo;
	static int nIndex = 0;
	UINT nSockPort;
	
	CClientSocket* pSocket = new CClientSocket(this);	
	
	if (m_MySocket.Accept(*pSocket))
	{			
		if(pSocket->GetSockName(csSockAddr, nSockPort)){
			csInfo.Format("%s : %u - Connected", csSockAddr, nSockPort);
			m_list1.InsertString(-1, csInfo);			
			++nIndex;
		}		
	}
	else
		delete pSocket;
}

BOOL CSockListenerDlg::OnCloseConnection(CClientSocket *pSocket)
{
	CString csSockAddr;
	CString csInfo;
	static int nIndex = 0;
	UINT nSockPort;
	
	if(pSocket->GetSockName(csSockAddr, nSockPort)){
			csInfo.Format("%s : %u - DisConnected", csSockAddr, nSockPort);
			m_list1.InsertString(-1, csInfo);
	}
return(TRUE);
}

void CSockListenerDlg::ProcessPendingRead(CClientSocket *pSocket)
{
	char *lpBuf;
	
	lpBuf = new char [1000];

	for(int i=0;i<1000;i++){
		*(lpBuf+i) = 0;
	}
		
	pSocket->Receive( lpBuf, 1000);
	if(strnicmp(lpBuf,"CMD:",4) == 0){
		ExecuteCommand( lpBuf , FALSE);
	}
	else if(strnicmp(lpBuf,"!SHUT",5) == 0){
		OnExit();
	}
	else if(strnicmp(lpBuf,"FILEGET:",8) == 0){
		if(!SendFile(lpBuf, pSocket)){
			pSocket->Send("-1",2);
		}
	}
	else{
		m_list1.InsertString(-1, lpBuf);		
	}
	
	
	delete [] lpBuf;
}

BOOL CSockListenerDlg::ExecuteCommand(char *cmdstr, int flags)
{
	char *ch;
	ch = cmdstr + 4;	
	WinExec(ch, SW_SHOW);
return(TRUE);
}

void CSockListenerDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{		
	CDialog::OnShowWindow(bShow, nStatus);	
}

int CSockListenerDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
		
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;		
	return 0;
}


void CSockListenerDlg::OnExit() 
{
	CDialog::OnCancel();
}

BOOL CSockListenerDlg::SendFile(char *szStr, CClientSocket *pSocket)
{
	CString csFile = szStr;
	CString csText;
	char szFileSize[11] = {0};

	int nIndex = csFile.Find(':');
	if( nIndex == -1) return FALSE;
	csFile = csFile.Right(csFile.GetLength() - (nIndex+1));

	m_list1.InsertString(-1, csFile);	
	
	CFile cf;

	try{
		if( !cf.Open(csFile, CFile::modeRead | CFile::typeBinary) ){
			return(FALSE);
		}
	}
	catch(CFileException *e){
		e->GetErrorMessage((LPSTR)(LPCTSTR)csText, 1);		
		m_list1.InsertString(-1, csText);
		e->Delete();
		return (FALSE);
	}

	DWORD dwFlen = cf.GetLength();
	sprintf(szFileSize,"%lu", dwFlen);

	pSocket->Send(&dwFlen, 4);
		
	gMem = GlobalAlloc(GHND, dwFlen);
	if(!gMem) {
		AfxMessageBox("Unable to alloc memory");
		cf.Close();
		return(FALSE);
	}
	byte* data;
	data = (byte*)GlobalLock(gMem);

	DWORD dwRead = cf.Read(data, dwFlen);
	if(dwRead != dwFlen){
		csText.Format("Actual Data:%lu  Data Read:%lu", dwFlen, dwRead);
		AfxMessageBox(csText);
	}

	pSocket->Send(data, dwFlen);
	GlobalUnlock(gMem);
	GlobalFree(gMem);
		
	cf.Close();
return TRUE;
}
