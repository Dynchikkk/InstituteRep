#if !defined(AFX_EDITIRCMESSAGELINE_H__DA43599D_1B9A_4617_AC7E_F508963352A4__INCLUDED_)
#define AFX_EDITIRCMESSAGELINE_H__DA43599D_1B9A_4617_AC7E_F508963352A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditIrcMessageLine.h : header file
//

#define	IRCEDN_RETURNPRESSED	(WM_USER+1001)

/////////////////////////////////////////////////////////////////////////////
// CEditIrcMessageLine window

class CEditIrcMessageLine : public CEdit
{
// Construction
public:
	CEditIrcMessageLine();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditIrcMessageLine)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditIrcMessageLine();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditIrcMessageLine)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITIRCMESSAGELINE_H__DA43599D_1B9A_4617_AC7E_F508963352A4__INCLUDED_)
