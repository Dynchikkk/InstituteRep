// TryIRC2Doc.h : interface of the CTryIRC2Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRYIRC2DOC_H__6CD1C080_79F3_45AD_ABFD_E8DD7EEFE0C5__INCLUDED_)
#define AFX_TRYIRC2DOC_H__6CD1C080_79F3_45AD_ABFD_E8DD7EEFE0C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

using namespace irc;

#define	IRCM_NOTIFY		(WM_USER+1000)


class CTryIRC2Doc : public CDocument, public CIrcDefaultMonitor
{
protected: // create from serialization only
	CTryIRC2Doc();
	DECLARE_DYNCREATE(CTryIRC2Doc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTryIRC2Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTryIRC2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	bool OnIrc_YOURHOST(const CIrcMessage* pmsg);
	bool OnIrc_NICK(const CIrcMessage* pmsg);
	bool OnIrc_PRIVMSG(const CIrcMessage* pmsg);
	bool OnIrc_JOIN(const CIrcMessage* pmsg);
	bool OnIrc_PART(const CIrcMessage* pmsg);
	bool OnIrc_KICK(const CIrcMessage* pmsg);
	bool OnIrc_MODE(const CIrcMessage* pmsg);

	virtual void OnIrcDefault(const CIrcMessage* pmsg);
	virtual void OnIrcDisconnected();

	DEFINE_IRC_MAP()

// Generated message map functions
protected:
	CView* m_pSystemView;
	//{{AFX_MSG(CTryIRC2Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CView* FindView(LPCTSTR lpszName);
	CView* CreateNewView(LPCTSTR lpszName);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRYIRC2DOC_H__6CD1C080_79F3_45AD_ABFD_E8DD7EEFE0C5__INCLUDED_)
