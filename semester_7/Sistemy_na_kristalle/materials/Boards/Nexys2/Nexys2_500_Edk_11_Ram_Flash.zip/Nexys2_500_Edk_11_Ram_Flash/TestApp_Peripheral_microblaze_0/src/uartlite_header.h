#define TESTAPP_GEN

/* $Id: uartlite_header.h,v 1.1 2008/08/27 12:04:58 sadanan Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus UartLiteSelfTestExample(Xuint16 DeviceId);


